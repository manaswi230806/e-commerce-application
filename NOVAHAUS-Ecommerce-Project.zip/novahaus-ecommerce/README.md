
# NOVAHAUS — Full-stack E-commerce Starter

A polished, responsive electronics/home-appliances storefront with a React + TypeScript + Vite frontend and an Express API backend. The local demo runs without external API keys.

## Requirements
- Node.js 20+ (recommended) and npm
- Internet connection for the first `npm install`

## Run it (Windows / macOS / Linux)
1. Extract the ZIP.
2. Open a terminal in the extracted `novahaus-ecommerce` folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start both frontend and backend:
   ```bash
   npm run dev
   ```
5. Open **http://localhost:5173**

The API runs at `http://localhost:4000`. You can check it at `http://localhost:4000/api/health`.

## Available features
- Responsive premium storefront, product search, category filters, sort, and product cards
- Product detail modal, wishlist, cart drawer, quantity controls, and cart totals
- Cart persisted in browser local storage
- Express API with product listing and order creation
- Checkout form with basic validation; orders are saved to `server/data/orders.json`
- Sample catalog in `server/data/products.json`
- Toast feedback, mobile-friendly layout, hover effects, reduced-motion support

## Important limitations (read before portfolio/demo use)
This is a runnable **local demo/starter**, not a production commerce system. It intentionally does not pretend to provide real payments, secure production authentication, a protected admin panel, or database-grade transactional inventory. Orders are stored in a local JSON file. Do not deploy this as-is for real customers or real personal/payment data.

To take it to production, replace the local JSON store with Supabase/PostgreSQL, implement Supabase Auth and Row Level Security, add server-side role enforcement, and integrate a payment provider in test mode first.
