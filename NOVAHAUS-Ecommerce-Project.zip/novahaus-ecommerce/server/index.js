
import express from 'express'
import cors from 'cors'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import crypto from 'node:crypto'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const dataDir = path.join(__dirname, 'data')
const productsFile = path.join(dataDir, 'products.json')
const ordersFile = path.join(dataDir, 'orders.json')
const app = express()
const PORT = process.env.PORT || 4000
app.use(cors({ origin: ['http://localhost:5173', 'http://127.0.0.1:5173'] }))
app.use(express.json({ limit: '1mb' }))
fs.mkdirSync(dataDir, { recursive: true })
if (!fs.existsSync(ordersFile)) fs.writeFileSync(ordersFile, '[]', 'utf8')

const readJson = (file, fallback) => {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')) } catch { return fallback }
}
const writeJson = (file, data) => fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8')

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'NOVAHAUS API' }))
app.get('/api/products', (_req, res) => res.json(readJson(productsFile, [])))
app.get('/api/products/:id', (req, res) => {
  const product = readJson(productsFile, []).find(p => p.id === Number(req.params.id))
  if (!product) return res.status(404).json({ error: 'Product not found' })
  res.json(product)
})
app.post('/api/orders', (req, res) => {
  const { customer, items } = req.body || {}
  if (!customer || !customer.name || !customer.email || !customer.phone || !customer.address || !/^\d{6}$/.test(String(customer.pincode || ''))) {
    return res.status(400).json({ error: 'Please provide valid delivery details.' })
  }
  if (!Array.isArray(items) || items.length === 0) return res.status(400).json({ error: 'Your cart is empty.' })
  const products = readJson(productsFile, [])
  let total = 0
  const orderItems = []
  for (const item of items) {
    const p = products.find(product => product.id === Number(item.productId))
    const qty = Number(item.quantity)
    if (!p || !Number.isInteger(qty) || qty < 1 || qty > p.stock) {
      return res.status(400).json({ error: 'One or more items are unavailable in the requested quantity.' })
    }
    total += p.price * qty
    orderItems.push({ productId: p.id, name: p.name, unitPrice: p.price, quantity: qty, lineTotal: p.price * qty })
  }
  const orders = readJson(ordersFile, [])
  const orderNumber = `NH-${crypto.randomBytes(4).toString('hex').toUpperCase()}`
  const order = {
    id: crypto.randomUUID(), orderNumber, createdAt: new Date().toISOString(),
    customer: { name: String(customer.name).slice(0, 100), email: String(customer.email).slice(0, 160), phone: String(customer.phone).slice(0, 30), address: String(customer.address).slice(0, 500), pincode: String(customer.pincode) },
    items: orderItems, total, status: 'Demo order received', paymentMethod: 'Cash on delivery demo'
  }
  orders.push(order)
  writeJson(ordersFile, orders)
  res.status(201).json({ orderNumber: order.orderNumber, total: order.total, status: order.status })
})
app.listen(PORT, () => console.log(`NOVAHAUS API listening on http://localhost:${PORT}`))
